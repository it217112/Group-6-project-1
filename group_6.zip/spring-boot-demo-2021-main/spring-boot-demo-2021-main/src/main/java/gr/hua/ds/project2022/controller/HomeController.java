package gr.hua.ds.project2022.controller;

import gr.hua.ds.project2022.repository.StudentRepository;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HomeController {

    private StudentRepository stuRep;


    @GetMapping("/")
    @Secured("ROLE_ADMIN")
    public String greeting(@RequestParam(name = "name", required = false, defaultValue = "World") String name, Model model) {
        model.addAttribute("name", name);
        return "greeting";
    }



}
