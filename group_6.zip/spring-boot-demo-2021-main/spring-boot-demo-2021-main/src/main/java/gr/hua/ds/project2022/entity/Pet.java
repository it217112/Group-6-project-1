package gr.hua.ds.project2022.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "pet")
public class Pet {

    @Id
    @Column(name = "microchip")
    private int microchip;

    @Column(name = "kind")
    private String kind;

    @Column(name = "sex")
    private String sex;

    @Column(name = "birth_date")
    private String birth_date;

    @Column(name = "email_vet")
    private String email_vet;

    @Column(name = "email_employee")
    private String email_employee;

    public Pet() {
    }

    public Pet(int microchip, String kind, String sex, String birth_date, String email_vet, String email_employee) {
        this.microchip = microchip;
        this.kind = kind;
        this.sex = sex;
        this.birth_date = birth_date;
        this.email_vet = email_vet;
        this.email_employee = email_employee;
    }

    public int getMicrochip() {
        return microchip;
    }

    public void setMicrochip(int microchip) {
        this.microchip = microchip;
    }

    public String getKind() {
        return kind;
    }

    public void setKind(String kind) {
        this.kind = kind;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getBirth_date() {
        return birth_date;
    }

    public void setBirth_date(String birth_date) {
        this.birth_date = birth_date;
    }

    public String getEmail_vet() {
        return email_vet;
    }

    public void setEmail_vet(String email_vet) {
        this.email_vet = email_vet;
    }

    public String getEmail_employee() {
        return email_employee;
    }

    public void setEmail_employee(String email_employee) {
        this.email_employee = email_employee;
    }
}