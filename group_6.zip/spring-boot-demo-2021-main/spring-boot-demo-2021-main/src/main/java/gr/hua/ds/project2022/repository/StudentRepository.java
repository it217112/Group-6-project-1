package gr.hua.ds.project2022.repository;

import gr.hua.ds.project2022.entity.Pet;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(path="students")
public interface StudentRepository extends JpaRepository<Pet, Integer> {
    //Pet findStudentById(int id);

}
