package gr.hua.ds.project2022.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

public class Application {

    @Entity
    @Table(name = "application")

    public class Application {
        @Id
        @Column(name = "number")
        private int number;

        @Column(name = "type")
        private String type;

        @Column(name = "state")
        private String state;

        @Column(name = "date")
        private Date date;

        @Column(name = "citizen_email")
        private String citizen_email;

        @Column(name = "email_employee")
        private String email_employee;

        @Column(name = "email_vet")
        private String email_vet;


        public Application() {
        }

        public Application(int number, String type, String state, Date date, String citizen_email, String email_employee, String email_vet) {
            this.number = number;
            this.type = type;
            this.state = state;
            this.date = date;
            this.citizen_email = citizen_email;
            this.email_employee = email_employee;
            this.email_vet = email_vet;
        }

        public int getNumber() {
            return number;
        }

        public void setNumber(int number) {
            this.number = number;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getState() {
            return state;
        }

        public void setState(String state) {
            this.state = state;
        }

        public Date getDate() {
            return date;
        }

        public void setDate(Date date) {
            this.date = date;
        }

        public String getCitizen_email() {
            return citizen_email;
        }

        public void setCitizen_email(String citizen_email) {
            this.citizen_email = citizen_email;
        }

        public String getEmail_employee() {
            return email_employee;
        }

        public void setEmail_employee(String email_employee) {
            this.email_employee = email_employee;
        }

        public String getEmail_vet() {
            return email_vet;
        }

        public void setEmail_vet(String email_vet) {
            this.email_vet = email_vet;
        }
    }
}
