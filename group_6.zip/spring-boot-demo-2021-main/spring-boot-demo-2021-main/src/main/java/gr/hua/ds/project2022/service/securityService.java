/*package gr.hua.ds.project2022.service;

public interface securityService {
    String findLoggedInUsername();

    void autoLogin(String username, String password);

    String findLoggedInUser();
    void autologin(String username, String password);
}
*/