

/*
INSERT INTO `student` VALUES
                          (1,'test','Adams','david@hua.gr'),
                          (2,'John','Doe','john@hua.gr'),
                          (3,'Ajay','Rao','ajay@hua.gr'),
                          (4,'Mary','Public','mary@hua.gr'),
                          (5,'Maxwell','Dixon','max@hua.gr');*/

CREATE TABLE IF NOT EXISTS 'citizen' (
    'email' varchar(50) NOT NULL ,
    'name' varchar(50) NOT NULL ,
    'address' varchar(50) NOT NULL ,
    'city' varchar(50) NOT NULL ,
    'phone' varchar(50) NOT NULL ,
    'pet_id' int NOT NULL ,
    'email_empl' varchar(50) NOT NULL ,
    PRIMARY KEY ('email'),
    CONSTRAINT 'fk_pet' FOREIGN KEY ('pet_id') REFERENCES 'pet' ('microchip'),
    CONSTRAINT 'fk_user' FOREIGN KEY ('email') REFERENCES 'user' ('email')
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `pet` (
                       `microchip` int(16) NOT NULL, /*microchips are up to 16 digits*/
                       `kind` varchar(45) DEFAULT NULL,
                       `sex` varchar(45) DEFAULT NULL,
                       `birth_date` date DEFAULT NULL,
                       'email_vet' varchar(50) DEFAULT NOT NULL,
                       'email_empl' varchar(50) DEFAULT NOT NULL,
                       PRIMARY KEY ('microchip')
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS 'employee' (
  'name' varchar(50) NOT NULL ,
  'email' varchar(50) NOT NULL ,
  'city' varchar(50) NOT NULL ,
  PRIMARY KEY ('email'),
  CONSTRAINT 'fk_user' FOREIGN KEY ('email') REFERENCES 'user' ('email')
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS 'vet' (
                           'name' varchar(50) NOT NULL ,
                           'email' varchar(50) NOT NULL ,
                           'city' varchar(50) NOT NULL ,
                           PRIMARY KEY ('email'),
                           CONSTRAINT 'fk_user' FOREIGN KEY ('email') REFERENCES 'user' ('email')
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE 'application' (
                           'number' int(10) NOT NULL ,
                           'type' varchar(50) NOT NULL ,
                            'state' varchar(50) NOT NULL ,
                            'date' date NOT NULL ,
                            'citizen_email' varchar(50) NOT NULL ,
                            'city' varchar(50) NOT NULL ,
                            'email_employee' varchar(50) NOT NULL ,
                            'email_vet' varchar(50) NOT NULL ,
                            PRIMARY KEY ('number'),
                            CONSTRAINT 'fk_citizen' FOREIGN KEY ('citizen_email') REFERENCES 'citizen' ('email'),
                            CONSTRAINT  'fk_employee' FOREIGN KEY ('email_employee') REFERENCES 'employee' ('email'),
                            CONSTRAINT 'fk_vet' FOREIGN KEY ('email_vet') REFERENCES 'vet' ('email')
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `user` (
    `email` varchar(50) NOT NULL,
    `password` varchar(100) NOT NULL,
    `enabled` tinyint(1) NOT NULL,
    PRIMARY KEY (`email`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `authorities` (
    `email` varchar(50) NOT NULL,
    `authority` varchar(50) NOT NULL,
    UNIQUE KEY `ix_auth_username` (`email`,`authority`),
    CONSTRAINT `fk_authorities_users` FOREIGN KEY (`email`) REFERENCES `user` (`email`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `pet`;


INSERT INTO `user` (`email`, `password`, `enabled`) VALUES
                                                           ('it21784@hua.gr', '123456789', 1);

INSERT INTO `authorities` (`email`, `authorities`.`authority`) VALUES
                                                        ('it21784@hua.gr', 'ROLE_ADMIN');
