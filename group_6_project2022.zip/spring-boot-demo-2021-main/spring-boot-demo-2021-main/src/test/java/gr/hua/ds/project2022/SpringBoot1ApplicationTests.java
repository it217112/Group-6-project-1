package gr.hua.ds.project2022;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBoot1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
