/*package gr.hua.ds.project2022.service;

import gr.hua.ds.project2022.entity.User;

public interface UserService {

    void save(User User);

    User findByUsername(String username);
}
*/