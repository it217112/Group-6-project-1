package gr.hua.ds.project2022.repository;

import gr.hua.ds.project2022.entity.Authority;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AuthoritiesRepository extends JpaRepository<Authority, String> {
}
