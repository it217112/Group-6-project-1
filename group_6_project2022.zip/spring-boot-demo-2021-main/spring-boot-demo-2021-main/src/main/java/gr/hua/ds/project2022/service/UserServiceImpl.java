/*package gr.hua.ds.project2022.service;

import gr.hua.ds.project2022.entity.User;
import gr.hua.ds.project2022.repository.AuthoritiesRepository;
import gr.hua.ds.project2022.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.HashSet;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private AuthoritiesRepository roleRepository;
    @Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;

    @Override
    public void save(User User) {
        User.setPassword(bCryptPasswordEncoder.encode(User.getPassword()));
        User.setRoles(new HashSet<>(roleRepository.findAll()));
        userRepository.save(User);
    }

    @Override
    public User findByUsername(String username) {
        return userRepository.finduserByUsername(username);
    }
}*/