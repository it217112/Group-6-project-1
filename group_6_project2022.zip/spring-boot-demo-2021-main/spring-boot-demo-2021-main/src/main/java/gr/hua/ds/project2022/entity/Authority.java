package gr.hua.ds.project2022.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "authorities")
public class Authority {

    @Id
    @Column(name = "email")
    private String email;

    @Column(name = "authority")
    private String authority;

    public Authority(){

    }

    public Authority(String email, String authority) {
        this.email = email;
        this.authority = authority;
    }

    public String getUsername() {
        return email;
    }

    public void setUsername(String username) {
        this.email = username;
    }

    public String getAuthority() {
        return authority;
    }

    public void setAuthority(String authority) {
        this.authority = authority;
    }

    @Override
    public String toString() {
        return "Authority{" +
                "email='" + email + '\'' +
                ", authority='" + authority + '\'' +
                '}';
    }
}
